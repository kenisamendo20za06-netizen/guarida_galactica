from flask import Flask, render_template, request, redirect, url_for, flash, session
from pymongo import MongoClient
from bson.objectid import ObjectId
import os

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "dev-secret")

# ----------------------------
# MONGO DB
# ----------------------------
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
client = MongoClient(MONGO_URI)
db = client["guarida_galactica"]

# ----------------------------
# PRODUCTOS
# ----------------------------
productos_disponibles = [
    {"id": 1, "nombre": "Estrella fugaz portátil", "precio": 250, "imagen": "estrella_fugaz.png"},
    {"id": 2, "nombre": "Parche de Conejo", "precio": 89, "imagen": "parche.png"},
    {"id": 3, "nombre": "Mini Planeta anti-estrés", "precio": 120, "imagen": "anti_estres.png"},
    {"id": 4, "nombre": "Luz Estelar", "precio": 150, "imagen": "luz.png"},
    {"id": 5, "nombre": "Cristal Lunar", "precio": 99, "imagen": "cristal.png"},
    {"id": 6, "nombre": "Espada Cósmica", "precio": 450, "imagen": "espada.png"},
    {"id": 7, "nombre": "NanoBot Omega", "precio": 299, "imagen": "robot.png"},
    {"id": 8, "nombre": "Poción Galáctica", "precio": 79, "imagen": "pocion.png"},
    {"id": 9, "nombre": "Asta Lunar", "precio": 180, "imagen": "asta.png"},
    {"id": 10, "nombre": "Chicle del Vacío", "precio": 20, "imagen": "chicle.png"},
    {"id": 11, "nombre": "Casco Nebuloso", "precio": 350, "imagen": "casco.png"},
    {"id": 12, "nombre": "Guantes de Plasma", "precio": 270, "imagen": "guantes.png"},
    {"id": 13, "nombre": "Mapa Estelar", "precio": 60, "imagen": "mapa.png"},
    {"id": 14, "nombre": "Zapatillas Antigravedad", "precio": 500, "imagen": "zapatos.png"},
    {"id": 15, "nombre": "Piedra Solar", "precio": 140, "imagen": "piedra.png"},
    {"id": 16, "nombre": "Visor Cuántico", "precio": 310, "imagen": "visor.png"},
    {"id": 17, "nombre": "Mini Cohete", "precio": 220, "imagen": "cohete.png"},
    {"id": 18, "nombre": "Compás Espacial", "precio": 85, "imagen": "compas.png"},
    {"id": 19, "nombre": "Bocina Interestelar", "precio": 45, "imagen": "bocina.png"},
    {"id": 20, "nombre": "Pulsera Planetaria", "precio": 55, "imagen": "pulsera.png"},
    {"id": 21, "nombre": "Memoria Galaxial", "precio": 130, "imagen": "memoria.png"},
    {"id": 22, "nombre": "Reloj del Multiverso", "precio": 250, "imagen": "reloj.png"},
    {"id": 23, "nombre": "Dulce Cósmico", "precio": 10, "imagen": "dulce.png"},
]

# ----------------------------
# INICIO
# ----------------------------
@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("principal_page"))
    return redirect(url_for("login_page"))

# ----------------------------
# PÁGINA PRINCIPAL
# ----------------------------
@app.route("/principal")
def principal_page():
    return render_template("principal.html", productos=productos_disponibles)

# ----------------------------
# LOGIN
# ----------------------------
@app.route("/login", methods=["GET", "POST"])
def login_page():
    if request.method == "POST":
        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "").strip()

        user = db.usuarios.find_one({"correo": correo, "password": password})

        if user:
            session["user_id"] = str(user["_id"])
            flash(f"Bienvenido de nuevo, {user['nombre']} 🐰", "success")
            return redirect(url_for("principal_page"))

        flash("Correo o contraseña incorrectos.", "danger⚠")

    return render_template("login.html")

# ----------------------------
# REGISTRO
# ----------------------------
@app.route("/registro", methods=["GET", "POST"])
def registro_page():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "").strip()

        if not nombre or not correo or not password:
            flash("Completa todos los campos.", "danger⚠")
            return redirect(url_for("registro_page"))

        if db.usuarios.find_one({"correo": correo}):
            flash("El correo ya está registrado.", "danger⚠")
            return redirect(url_for("registro_page"))

        nuevo_usuario = {
            "nombre": nombre,
            "correo": correo,
            "password": password
        }

        result = db.usuarios.insert_one(nuevo_usuario)
        session["user_id"] = str(result.inserted_id)

        flash(f"¡Bienvenida, {nombre}! 🐰✨", "success")
        return redirect(url_for("perfil_page", id=session["user_id"]))

    return render_template("registro.html")

# ----------------------------
# PERFIL
# ----------------------------
@app.route("/perfil/<id>")
def perfil_page(id):
    try:
        usuario = db.usuarios.find_one({"_id": ObjectId(id)})
    except:
        usuario = None

    if not usuario:
        flash("Usuario no encontrado.", "danger⚠")
        return redirect(url_for("login_page"))

    usuario["id"] = str(usuario["_id"])
    return render_template("perfil.html", usuario=usuario)

# ----------------------------
# V.A.C.
# ----------------------------
@app.route("/vac")
def vac_page():
    return render_template("vac.html", productos=productos_disponibles)

# ----------------------------
# CARRITO
# ----------------------------
@app.route("/carrito")
def carrito_page():
    carrito = session.get("carrito", {})
    productos_carrito = []

    for p in productos_disponibles:
        pid = str(p["id"])
        if pid in carrito:
            item = p.copy()
            item["cantidad"] = carrito[pid]
            item["subtotal"] = item["cantidad"] * item["precio"]
            productos_carrito.append(item)

    total = sum(x["subtotal"] for x in productos_carrito)

    return render_template("carrito.html", productos=productos_carrito, total=total)

@app.route("/carrito/agregar/<int:producto_id>")
def agregar_producto(producto_id):
    carrito = session.get("carrito", {})
    pid = str(producto_id)
    carrito[pid] = carrito.get(pid, 0) + 1
    session["carrito"] = carrito
    return redirect(url_for("carrito_page"))

@app.route("/carrito/quitar/<int:producto_id>")
def quitar_producto(producto_id):
    carrito = session.get("carrito", {})
    pid = str(producto_id)

    if pid in carrito:
        carrito[pid] -= 1
        if carrito[pid] <= 0:
            carrito.pop(pid)

    session["carrito"] = carrito
    return redirect(url_for("carrito_page"))

@app.route("/carrito/eliminar/<int:producto_id>")
def eliminar_producto(producto_id):
    carrito = session.get("carrito", {})
    pid = str(producto_id)

    if pid in carrito:
        carrito.pop(pid)

    session["carrito"] = carrito
    return redirect(url_for("carrito_page"))

@app.route("/carrito/pagar")
def pagar():
    session.pop("carrito", None)
    flash("¡Gracias por tu compra! 🐰✨", "success")
    return redirect(url_for("principal_page"))

# ----------------------------
# RUN
# ----------------------------
if __name__ == "__main__":
    app.run(debug=True)
